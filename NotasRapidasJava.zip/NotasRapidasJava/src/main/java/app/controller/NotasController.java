package app.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

public class NotasController {

    private final TextField input;
    private final ListView<String> lista;
    private final Label lblContador;

    private final ObservableList<String> notas;

    public NotasController(
            TextField input,
            ListView<String> lista,
            Label lblContador
    ) {

        this.input = input;
        this.lista = lista;
        this.lblContador = lblContador;

        notas = FXCollections.observableArrayList();

        lista.setItems(notas);

        actualizarContador();
    }

    // ActionEvent - Agregar
    public void manejarAgregar(ActionEvent event) {
        agregarNota();
    }

    // ActionEvent - Eliminar
    public void manejarEliminar(ActionEvent event) {

        int indice =
                lista.getSelectionModel()
                     .getSelectedIndex();

        if (indice >= 0) {

            notas.remove(indice);

            actualizarContador();
        }
    }

    // KeyEvent - Enter
    public void manejarTeclado(KeyEvent event) {

        if (event.getCode() == KeyCode.ENTER) {

            agregarNota();
        }
    }

    // MouseEvent - Doble clic
    public void manejarMouse(MouseEvent event) {

        if (event.getClickCount() == 2) {

            int indice =
                    lista.getSelectionModel()
                         .getSelectedIndex();

            if (indice >= 0) {

                editarNota(indice);
            }
        }
    }

    private void agregarNota() {

        String texto =
                input.getText().trim();

        if (!texto.isEmpty()) {

            notas.add(texto);

            input.clear();

            input.requestFocus();

            actualizarContador();
        }
    }

    private void editarNota(int indice) {

        String actual =
                notas.get(indice);

        TextInputDialog dialogo =
                new TextInputDialog(actual);

        dialogo.setTitle("Editar nota");

        dialogo.setHeaderText(
                "Editar nota"
        );

        dialogo.setContentText(
                "Nuevo texto:"
        );

        dialogo.showAndWait()
                .ifPresent(nuevoTexto -> {

                    String texto =
                            nuevoTexto.trim();

                    if (!texto.isEmpty()) {

                        notas.set(
                                indice,
                                texto
                        );
                    }
                });
    }

    private void actualizarContador() {

        int cantidad = notas.size();

        if (cantidad == 1) {

            lblContador.setText(
                    "1 nota"
            );

        } else {

            lblContador.setText(
                    cantidad + " notas"
            );
        }
    }
}